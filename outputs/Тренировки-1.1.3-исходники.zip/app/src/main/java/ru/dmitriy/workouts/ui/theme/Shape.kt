package ru.dmitriy.workouts.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

object Space {
    val None = 0.dp
    val Hairline = 1.dp
    val Tiny = 4.dp
    val Small = 8.dp
    val Medium = 12.dp
    val Regular = 16.dp
    val Large = 20.dp
    val Section = 24.dp
    val Huge = 32.dp
    val Hero = 40.dp
    val Touch = 48.dp
    val Action = 56.dp
    val WeightField = 96.dp
    val Chart = 112.dp
    val MaxContent = 760.dp
    val Icon = 22.dp
    val Dot = 6.dp
    val Navigation = 72.dp
    val NavigationItem = 64.dp
    val NavigationLargeItem = 88.dp
    val NavigationHaloWidth = 56.dp
    val NavigationHaloHeight = 32.dp
    val Stroke = 2.dp
    val BrandWidth = 72.dp
    val BrandHeight = 32.dp
    val Rhythm = 268.dp
    val RhythmCompact = 220.dp
    val Editor = 200.dp
    val Step = 52.dp
    val Peek = 64.dp
    val ComposerMax = 160.dp
    val CompactWorkout = 540.dp
}
object AppShapes {
    val Surface = RoundedCornerShape(22.dp)
    val Control = RoundedCornerShape(20.dp)
    val Chip = RoundedCornerShape(14.dp)
    val Round = RoundedCornerShape(50)
}
object Motion {
    const val Duration = 300
    const val PressedScale = .985f
    const val NaturalScale = 1f
}
