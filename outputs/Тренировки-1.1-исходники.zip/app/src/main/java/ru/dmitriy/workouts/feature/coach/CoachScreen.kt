package ru.dmitriy.workouts.feature.coach

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.tooling.preview.Preview
import ru.dmitriy.workouts.domain.*
import ru.dmitriy.workouts.feature.plan.operationLabel
import ru.dmitriy.workouts.feature.plan.operationValue
import ru.dmitriy.workouts.feature.plan.proposalStatus
import ru.dmitriy.workouts.feature.shared.*
import ru.dmitriy.workouts.ui.theme.*

/** Native conversation and reviewed changes. Model-generated code is never executed. */
@Composable fun CoachScreen(
    state: LocalState, connected: Boolean, phase: String, response: String, error: String?, contextLabel: String,
    onSend: (String) -> Unit, onCancel: () -> Unit, onConnect: () -> Unit, onConversation: (String) -> Unit,
    selectedConversationId: String?, onNew: () -> Unit, onProposal: (String) -> Unit, onInsight: (String) -> Unit,
    initialDraft: String = "", persistedDraft: String? = null, onDraft: (String) -> Unit = {},
    onRequestProposal: ((String) -> Unit)? = null,
    onApplyProposal: ((String) -> Unit)? = null, onRejectProposal: ((String) -> Unit)? = null,
    targetSessionId: String? = null,
    onBack: (() -> Unit)? = null,
) {
    var localDraft by rememberSaveable(initialDraft) { mutableStateOf(initialDraft) }
    val draft = persistedDraft ?: localDraft
    fun setDraft(value: String) { localDraft = value; onDraft(value) }
    var details by rememberSaveable { mutableStateOf(false) }
    var history by rememberSaveable { mutableStateOf(false) }
    val list = rememberLazyListState()
    val messages = state.messages.filter { it.conversationId == selectedConversationId }.sortedBy { it.createdAt }
    val selectedConversation = state.conversations.find { it.id == selectedConversationId }
    val proposal = state.proposals.lastOrNull { it.sessionId == (selectedConversation?.sessionId ?: targetSessionId) }
    val sending = phase in listOf("sending", "receiving", "streaming", "connecting")
    LaunchedEffect(selectedConversationId, messages.size, sending, proposal?.proposalId) {
        if (list.layoutInfo.totalItemsCount > 0) list.animateScrollToItem(list.layoutInfo.totalItemsCount - 1)
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = Space.Large), verticalAlignment = Alignment.CenterVertically) {
            if (onBack != null) IconAction(Icons.Default.ArrowBack, "Назад к занятию", onBack)
            Column(Modifier.weight(1f)) {
                Text("ИИ-тренер", style = AppType.Title, color = AppColors.Text)
                Text("DeepSeek", style = AppType.Label, color = AppColors.Secondary)
            }
            IconAction(Icons.Default.History, "Диалоги и разборы", { history = !history })
            IconAction(Icons.Default.Settings, "Настройки помощника", onConnect)
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = Space.Large), verticalAlignment = Alignment.CenterVertically) {
            Text(contextLabel.removePrefix("Контекст: "), style = AppType.Label, color = AppColors.Secondary, modifier = Modifier.weight(1f))
            IconAction(Icons.Default.Info, "Какие записи используются", { details = !details })
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = list,
            contentPadding = PaddingValues(horizontal = Space.Large, vertical = Space.Small),
            verticalArrangement = Arrangement.spacedBy(Space.Regular)) {
            if (details) item {
                Panel(Modifier.fillMaxWidth(), outlined = true) {
                    Text("Для ответа", style = AppType.Heading, color = AppColors.Text)
                    Text("Цель, неделя программы, выбранные упражнения и недавние подходы. Заметки — только с вашего разрешения в настройках.",
                        style = AppType.Body, color = AppColors.Secondary)
                    ActionButton("Настроить", onConnect)
                }
            }
            if (history) item {
                Column(verticalArrangement = Arrangement.spacedBy(Space.Small)) {
                    ActionButton("Новый диалог", { onNew(); history = false }, Modifier.fillMaxWidth())
                    val conversations = state.conversations.filter { it.id != "local-draft" }.sortedByDescending { it.createdAt }
                    conversations.forEach { conversation ->
                        ActionButton(conversation.title, { onConversation(conversation.id); history = false }, Modifier.fillMaxWidth())
                    }
                    state.insights.sortedByDescending { it.createdAt }.forEach { insight ->
                        ActionButton("${insight.period} · ${formatDate(insight.createdAt)}", { onInsight(insight.id) }, Modifier.fillMaxWidth())
                    }
                    if (conversations.isEmpty() && state.insights.isEmpty()) Text("Здесь появятся сохранённые диалоги и разборы.", style = AppType.Body, color = AppColors.Secondary)
                }
            }
            if (messages.isEmpty() && !sending) item {
                Column(verticalArrangement = Arrangement.spacedBy(Space.Medium)) {
                    Text("С чего начнём?", style = AppType.Heading, color = AppColors.Text)
                    ActionButton("Как выбрать вес?", { setDraft("Как выбрать первый рабочий вес?") }, Modifier.fillMaxWidth())
                    ActionButton("Сколько оставить в запасе?", { setDraft("Как понять, сколько повторений осталось в запасе?") }, Modifier.fillMaxWidth())
                    if (onRequestProposal != null) ActionButton("Осталось 30 минут", { setDraft("Осталось 30 минут. Предложи, как сократить оставшуюся часть занятия.") }, Modifier.fillMaxWidth())
                }
            }
            items(messages, key = { it.id }) { message ->
                Column(Modifier.fillMaxWidth(), horizontalAlignment = if (message.role == "user") Alignment.End else Alignment.Start,
                    verticalArrangement = Arrangement.spacedBy(Space.Small)) {
                    if (message.role != "user") Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Space.Small)) {
                        Icon(Icons.Default.AutoAwesome, null, tint = AppColors.Accent, modifier = Modifier.size(Space.Icon))
                        Text("ИИ-помощник", style = AppType.Label, color = AppColors.Accent)
                    }
                    if (message.role == "user") Panel { Text(message.content, style = AppType.Body, color = AppColors.Text) }
                    else Text(message.content.ifBlank { "Ответ не получен" }, style = AppType.Body, color = AppColors.Text)
                    if (message.state != "saved") Text(messageState(message.state), style = AppType.Label, color = AppColors.Secondary)
                }
            }
            if (sending) item {
                Column(verticalArrangement = Arrangement.spacedBy(Space.Medium)) {
                    Text("ИИ-помощник", style = AppType.Label, color = AppColors.Accent)
                    Text(response.ifBlank { "Готовлю ответ…" }, style = AppType.Body, color = AppColors.Text)
                    ActionButton("Остановить", onCancel)
                }
            }
            if (proposal != null) item(key = proposal.proposalId) {
                CoachProposalCard(proposal, state.exercises, { onProposal(proposal.proposalId) },
                    onApplyProposal?.let { action -> { action(proposal.proposalId) } },
                    onRejectProposal?.let { action -> { action(proposal.proposalId) } })
            }
            if (error != null && phase != "cancelled") item {
                Panel(Modifier.fillMaxWidth(), outlined = true) {
                    Text("Ответ недоступен", style = AppType.Heading, color = AppColors.Error)
                    Text(error, style = AppType.Body, color = AppColors.Secondary)
                    if (connected && messages.lastOrNull { it.role == "user" } != null) ActionButton("Повторить вопрос", {
                        setDraft(messages.last { it.role == "user" }.content)
                    })
                }
            }
            if (phase == "cancelled") item { Text("Ответ остановлен", style = AppType.Label, color = AppColors.Secondary) }
            if (!connected) item {
                Panel(Modifier.fillMaxWidth(), outlined = true) {
                    Text("Добавьте ключ DeepSeek", style = AppType.Heading, color = AppColors.Text)
                    Text("Для новых ответов нужен интернет. Сохранённое доступно всегда.", style = AppType.Body, color = AppColors.Secondary)
                    ActionButton("Подключить", onConnect, Modifier.fillMaxWidth(), primary = true)
                }
            }
        }
        DividerLine()
        Column(Modifier.fillMaxWidth().background(AppColors.Background).padding(horizontal = Space.Large, vertical = Space.Small),
            verticalArrangement = Arrangement.spacedBy(Space.Small)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(Space.Small)) {
                Input(draft, ::setDraft, if (connected) "Ваш вопрос" else "Черновик", Modifier.weight(1f).heightIn(max = Space.ComposerMax), multiline = true)
                ActionButton("", { onSend(draft) }, Modifier.semantics { contentDescription = "Отправить" }, primary = true,
                    enabled = connected && draft.isNotBlank() && !sending, icon = Icons.AutoMirrored.Filled.Send)
            }
            if (onRequestProposal != null && draft.isNotBlank()) ActionButton("Предложить изменение", { onRequestProposal(draft) },
                Modifier.fillMaxWidth(), enabled = connected && !sending)
        }
    }
}

@Composable private fun CoachProposalCard(proposal: PlanProposal, exercises: List<Exercise>, onOpen: () -> Unit,
    onApply: (() -> Unit)?, onReject: (() -> Unit)?) {
    var reason by rememberSaveable(proposal.proposalId) { mutableStateOf(false) }
    val current = proposal.status == "proposed" && proposal.expiresAt > System.currentTimeMillis()
    Panel(Modifier.fillMaxWidth(), outlined = true) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Space.Small)) {
            Icon(Icons.Default.AutoAwesome, null, tint = AppColors.Accent, modifier = Modifier.size(Space.Icon))
            Text(if (current) "Предложение" else if (proposal.status == "proposed") "Устарело" else proposalStatus(proposal.status), style = AppType.Label, color = AppColors.Accent)
        }
        Text(proposal.summary, style = AppType.Heading, color = AppColors.Text)
        proposal.operations.forEach { operation ->
            Column(verticalArrangement = Arrangement.spacedBy(Space.Small)) {
                Text(exercises.find { it.id == operation.exerciseId }?.name ?: operationLabel(operation.type), style = AppType.Label, color = AppColors.Text)
                Text("${operationValue(operation.type, operation.previous, exercises)} → ${operationValue(operation.type, operation.value, exercises)}",
                    style = AppType.Heading, color = AppColors.Accent)
                DividerLine()
            }
        }
        Text(if (proposal.scope == "session") "Только это занятие" else "Будущие занятия", style = AppType.Label, color = AppColors.Secondary)
        if (current) {
            ActionButton("Применить", onApply ?: onOpen, Modifier.fillMaxWidth(), primary = true)
            if (onReject != null) ActionButton("Оставить как есть", onReject, Modifier.fillMaxWidth())
        } else if (proposal.status in listOf("stale", "proposed")) Text("Записи изменились или прошло много времени. Попросите новое предложение.", style = AppType.Body, color = AppColors.Secondary)
        Chip(if (reason) "Скрыть причину" else "Почему так?") { reason = !reason }
        if (reason) {
            Text(proposal.reason, style = AppType.Body, color = AppColors.Secondary)
            ActionButton("Все подробности", onOpen, Modifier.fillMaxWidth())
        }
    }
}

fun formatDate(epoch: Long): String = java.time.Instant.ofEpochMilli(epoch).atZone(java.time.ZoneId.systemDefault()).toLocalDate().format(java.time.format.DateTimeFormatter.ofPattern("dd.MM.yyyy"))
private fun messageState(state: String): String = when (state) { "sending" -> "Отправляется"; "cancelled" -> "Остановлено"; "error" -> "Ответ не получен"; "streaming" -> "Получение ответа"; else -> "Сохранено" }

@Preview(name = "Тренер", widthDp = 390, heightDp = 850)
@Composable private fun CoachPreview() = WorkoutsTheme { CoachScreen(PreviewFixtures.state, false, "idle", "", null, "Программа · неделя 1", {}, {}, {}, {}, null, {}, {}, {}) }
