package ru.dmitriy.workouts.feature

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.CancellationException
import ru.dmitriy.workouts.core.timer.RestTimer
import ru.dmitriy.workouts.data.*
import ru.dmitriy.workouts.data.ai.AiRepository
import ru.dmitriy.workouts.domain.*
import ru.dmitriy.workouts.feature.workout.SetDraft
import java.time.LocalDate
import java.util.UUID
import javax.inject.Inject

@OptIn(FlowPreview::class)
@HiltViewModel class AppViewModel @Inject constructor(
    private val repository: WorkoutRepository,
    private val preferences: SettingsRepository,
    private val assistant: AiRepository,
    val timer: RestTimer,
) : ViewModel() {
    val local = repository.state.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), LocalState())
    val settings = preferences.settings.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppSettings())
    val ai = assistant.state
    val connected = assistant.connected
    val error = MutableStateFlow<String?>(null)
    val selectedExercise = MutableStateFlow(0)
    val conversationId = MutableStateFlow<String?>(null)
    val draft = MutableStateFlow("")
    private var savingSet = false
    private var dialogueGeneration = 0L
    private var sendingGeneration: Long? = null
    init {
        action {
            repository.seed()
            draft.value = repository.snapshot().messages.find { it.id == "local-draft" }?.content.orEmpty()
            draft.drop(1).debounce(400).collect { text -> runCatching { repository.saveCoachDraft(text) } }
        }
    }
    fun updateDraft(value: String) { draft.value = value.take(2000) }
    fun progression(exerciseId: String, equipmentId: String): ProgressionDecision? {
        val saved=local.value
        val target=saved.sessions.firstOrNull { it.status=="active" }?.exercises?.find { it.exerciseId==exerciseId && it.equipmentId==equipmentId }?.target
            ?: saved.program.targets.find { it.exerciseId==exerciseId && it.equipmentId==equipmentId }
        return saved.equipment.find { it.id==equipmentId }?.let { ProgressionEngine().evaluate(exerciseId,it,saved.sessions,target) }
    }
    private fun action(block: suspend () -> Unit) { viewModelScope.launch {
        try { block() }
        catch (cancelled: CancellationException) { throw cancelled }
        catch (failure: Exception) { error.value = failure.message ?: "Не удалось выполнить действие" }
    } }
    fun clearError() { error.value = null }
    fun profile(profile: Profile) = action { repository.saveProfile(profile); preferences.update { it.copy(onboarded = true) } }
    fun settings(value: AppSettings) = action { preferences.update { value } }
    fun connect(base: String, code: String) = action { assistant.connect(base, code) }
    fun disconnect() = action { assistant.disconnect() }
    fun start(onStarted: (String) -> Unit) = action { val id = repository.startWorkout(); selectedExercise.value = 0; onStarted(id) }
    fun selectExercise(index: Int) { selectedExercise.value = index }
    fun saveSet(sessionId: String, exerciseId: String, draft: SetDraft) {
        if (savingSet) return
        savingSet = true
        action {
            try {
                repository.saveSet(sessionId, exerciseId, draft.index, draft.weightGrams, draft.reps, draft.rir, draft.technique, draft.warmup)
                if (!draft.warmup) repository.snapshot().sessions.find { it.id == sessionId && it.status == "active" }?.exercises?.find { it.exerciseId == exerciseId }?.let { timer.start(it.target.restSeconds) }
            } finally { savingSet = false }
        }
    }
    fun unmark(id: String) = action { repository.unmarkSet(id) }
    fun rest(sessionId:String,exerciseId:String,seconds:Int,saveToPlan:Boolean)=action { repository.updateSessionRest(sessionId,exerciseId,seconds,saveToPlan) }
    fun finish(id: String, partial: Boolean, onFinished: () -> Unit) = action { repository.finishWorkout(id, partial); timer.skip(); onFinished() }
    fun program(program: Program) = action { repository.updateProgram(program) }
    fun nextStage(keepTwoDays: Boolean) = action {
        val old = repository.snapshot().program
        val next = ProgramRules.forWeek(old, (old.week + 1).coerceAtMost(8))
        repository.updateProgram(if (keepTwoDays && old.weekdays.size == 2) next.copy(weekdays = old.weekdays) else next)
    }
    fun equipment(value: EquipmentProfile) = action { repository.saveEquipment(value) }
    fun chooseEquipment(value: EquipmentProfile, sessionId: String?) = action {
        repository.saveEquipment(value)
        if (sessionId != null) repository.selectSessionEquipment(sessionId, value.exerciseId, value.id)
        else {
            val program = repository.snapshot().program
            repository.updateProgram(program.copy(targets = program.targets.map { if (it.exerciseId == value.exerciseId) it.copy(equipmentId = value.id, weightGrams = null) else it }))
        }
    }
    fun exerciseNote(sessionId: String, exerciseId: String, note: String) = action { repository.saveExerciseNote(sessionId, exerciseId, note) }
    fun bodyWeight(grams: Int) = action { repository.addBodyWeight(grams) }
    fun checkIn(fatigue: Int?, minutes: Int?) = action { repository.saveCheckIn(ReadinessCheckIn(UUID.randomUUID().toString(), LocalDate.now().toString(), fatigue, minutes)) }
    fun apply(id: String, onDone: () -> Unit) = action { repository.applyProposal(id); onDone() }
    fun reject(id: String, onDone: () -> Unit) = action { repository.rejectProposal(id); onDone() }
    fun rollback(id: String) = action { repository.rollback(id) }
    private suspend fun prepareConversation(prompt:String,sessionId:String?,exerciseId:String?,selected:String?,generation:Long):String? {
        val saved=repository.snapshot()
        if(generation!=dialogueGeneration)return null
        val explicit=saved.conversations.find { it.id==selected }
        val current=explicit?.takeIf { it.sessionId==sessionId && it.exerciseId==exerciseId }
            ?: if(selected!=null && explicit==null)CoachConversation(selected,prompt.take(60),System.currentTimeMillis(),exerciseId,sessionId)
            else saved.conversations.lastOrNull { it.id!="local-draft" && it.sessionId==sessionId && it.exerciseId==exerciseId }
                ?: CoachConversation(UUID.randomUUID().toString(),prompt.take(60),System.currentTimeMillis(),exerciseId,sessionId)
        if(saved.conversations.none { it.id==current.id })repository.addConversation(current)
        if(generation!=dialogueGeneration)return null
        conversationId.value=current.id
        return current.id
    }
    private suspend fun clearSavedDraft(prompt:String,generation:Long) {
        // A newer draft or another dialogue must survive completion of this save.
        if(generation==dialogueGeneration && draft.value==prompt) {
            draft.value=""
            repository.saveCoachDraft("")
        }
    }
    fun send(prompt: String, sessionId: String?, exerciseId: String?) {
        val generation=dialogueGeneration
        val selected=conversationId.value
        if(sendingGeneration==generation)return
        sendingGeneration=generation
        action {
            try {
                val id=prepareConversation(prompt,sessionId,exerciseId,selected,generation) ?: return@action
                if(generation==dialogueGeneration)assistant.chat(prompt,sessionId,exerciseId,id,
                    onQuestionSaved={clearSavedDraft(prompt,generation)})
            } finally { if(sendingGeneration==generation)sendingGeneration=null }
        }
    }
    fun conversation(id: String?) {
        dialogueGeneration++
        assistant.resetUi()
        conversationId.value=id
    }
    fun newConversation(sessionId: String? = null, exerciseId: String? = null) {
        val id = UUID.randomUUID().toString()
        conversation(id)
        action { repository.addConversation(CoachConversation(id, "Новый диалог", System.currentTimeMillis(), exerciseId = exerciseId, sessionId = sessionId)) }
    }
    fun cancelAi() { assistant.cancel() }
    fun insight(kind: String, sessionId: String?, force: Boolean = false, onDone: (String) -> Unit) = action {
        val generation=dialogueGeneration
        assistant.insight(kind, sessionId, force)
        if (generation==dialogueGeneration && assistant.state.value.phase in setOf("done", "cached")) {
            repository.snapshot().insights.filter { it.type == kind && (sessionId == null || sessionId in it.evidenceIds) }.maxByOrNull { it.createdAt }?.let { onDone(it.id) }
        }
    }
    fun propose(prompt: String, sessionId: String?, onDone: (String) -> Unit) {
        val generation=dialogueGeneration
        val selected=conversationId.value
        if(sendingGeneration==generation)return
        sendingGeneration=generation
        action {
            try { proposeNow(prompt,sessionId,selected,generation,onDone) }
            finally { if(sendingGeneration==generation)sendingGeneration=null }
        }
    }
    fun proposeForToday(prompt: String, onDone: (String) -> Unit) {
        conversation(null)
        val generation=dialogueGeneration
        sendingGeneration=generation
        action {
            try {
                val existing=repository.snapshot().sessions.firstOrNull { it.status=="active" }
                val sessionId=repository.startWorkout()
                if(existing==null)selectedExercise.value=0
                if(generation==dialogueGeneration)proposeNow(prompt,sessionId,null,generation,onDone)
            } finally { if(sendingGeneration==generation)sendingGeneration=null }
        }
    }
    private suspend fun proposeNow(prompt:String,sessionId:String?,selected:String?,generation:Long,onDone:(String)->Unit) {
        val exerciseId=repository.snapshot().conversations.find { it.id==selected && it.sessionId==sessionId }?.exerciseId
        val id=prepareConversation(prompt,sessionId,exerciseId,selected,generation) ?: return
        if(generation!=dialogueGeneration)return
        assistant.propose(prompt,sessionId,id,onQuestionSaved={clearSavedDraft(prompt,generation)})
        if(generation==dialogueGeneration && assistant.state.value.phase=="done") {
            repository.snapshot().proposals.filter { it.sessionId == sessionId }.maxByOrNull { it.expiresAt }?.let { onDone(it.proposalId) }
        }
    }
    fun clearChats() = action {
        conversation(null)
        val old = repository.snapshot()
        repository.replaceAll(old.copy(conversations = emptyList(), messages = emptyList(), insights = emptyList()))
        conversationId.value = null
        draft.value = ""
    }
}
