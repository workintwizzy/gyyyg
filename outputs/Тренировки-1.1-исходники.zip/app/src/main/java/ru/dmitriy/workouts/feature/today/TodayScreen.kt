package ru.dmitriy.workouts.feature.today

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import ru.dmitriy.workouts.domain.*
import ru.dmitriy.workouts.feature.AppDialog
import ru.dmitriy.workouts.feature.shared.*
import ru.dmitriy.workouts.ui.theme.*
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable fun TodayScreen(state: LocalState, onStart: () -> Unit, onTechnique: (String) -> Unit, onAdapt: (String) -> Unit, onReschedule: () -> Unit, onCheckIn: () -> Unit, onInsight: (String) -> Unit, onSettings: () -> Unit = {}) {
    val active = state.sessions.firstOrNull { it.status == "active" }
    var sheet by rememberSaveable { mutableStateOf("") }
    val targets = active?.exercises?.map { it.target } ?: state.program.targets
    val week = active?.assignedSnapshot?.week ?: state.program.week
    val fontScale = LocalDensity.current.fontScale
    val dateLabel = remember(state.program.nextDate) {
        runCatching { LocalDate.parse(state.program.nextDate).format(DateTimeFormatter.ofPattern("d MMMM", Locale.forLanguageTag("ru"))) }.getOrDefault("")
    }
    val header: @Composable () -> Unit = {
        Text("Всё тело", style = AppType.Hero.copy(fontSize = 40.sp, lineHeight = 48.sp, letterSpacing = (-1.5).sp), color = AppColors.Text, textAlign = TextAlign.Center)
        Spacer(Modifier.height(Space.Small))
        Text("Неделя $week · ${targets.size} упражнений", style = AppType.Label, color = AppColors.Secondary, textAlign = TextAlign.Center)
    }
    val footer: @Composable () -> Unit = {
        Panel(Modifier.fillMaxWidth(), outlined = true) {
            if (active != null) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Подходы", style = AppType.Label, color = AppColors.Secondary)
                    Text("${active.completedWorkSets()} / ${active.assignedWorkSets()}", style = AppType.Label.copy(fontWeight = FontWeight.Bold, fontFeatureSettings = "tnum"), color = AppColors.Accent)
                }
            }
            ActionButton(if (active == null) "Начать" else "Продолжить", onStart, Modifier.fillMaxWidth(), primary = true, icon = Icons.Default.PlayArrow)
            FlowRow(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Space.Medium, Alignment.CenterHorizontally), verticalArrangement = Arrangement.spacedBy(Space.Small)) {
                TextAction("Настроить", { sheet = "adjust" }, icon = Icons.Default.Tune)
                TextAction("Упражнения", { sheet = "plan" }, icon = Icons.Default.FormatListBulleted)
            }
        }
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = Space.Section, vertical = Space.Small), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f).clickable(role = Role.Button, onClick = onReschedule).heightIn(min = Space.Touch), verticalArrangement = Arrangement.Center) {
                Text("Сегодня", style = AppType.Heading, color = AppColors.Text)
                if (active == null && dateLabel.isNotBlank()) Text(dateLabel, style = AppType.Label, color = AppColors.Secondary)
            }
            IconAction(Icons.Outlined.Settings, "Настройки", onSettings)
        }
        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
            val compact = maxHeight < 520.dp || fontScale > 1.4f
            if (compact) {
                Column(Modifier.widthIn(max = 480.dp).fillMaxWidth().verticalScroll(rememberScrollState()).padding(Space.Section),
                    horizontalAlignment = Alignment.CenterHorizontally) {
                    header()
                    Box(Modifier.fillMaxWidth().height(200.dp), contentAlignment = Alignment.Center) { TrainingBloom(Modifier.size(240.dp)) }
                    footer()
                }
            } else {
                val artSize = minOf(maxWidth + Space.Huge, (maxHeight * .65f).coerceIn(260.dp, 380.dp))
                Column(Modifier.widthIn(max = 480.dp).fillMaxSize().padding(horizontal = Space.Section, vertical = Space.Section),
                    horizontalAlignment = Alignment.CenterHorizontally) {
                    header()
                    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { TrainingBloom(Modifier.size(artSize)) }
                    footer()
                }
            }
        }
    }
    if (sheet == "adjust") AppDialog("Настроить занятие", { sheet = "" }) {
        ActionButton("У меня 30 минут", { sheet = ""; onAdapt("У меня 30 минут. Предложи сокращение оставшейся части занятия.") }, Modifier.fillMaxWidth())
        ActionButton("Сегодня полегче", { sheet = ""; onAdapt("Я сильно устал. Предложи облегчение оставшейся части занятия.") }, Modifier.fillMaxWidth())
        Text("Изменения сначала покажет помощник. Решение за вами.", style = AppType.Label, color = AppColors.Secondary)
        DividerLine()
        TextAction("Перенести дату", { sheet = ""; onReschedule() })
        TextAction("Самочувствие и время", { sheet = ""; onCheckIn() })
        state.insights.maxByOrNull { it.createdAt }?.let { insight -> TextAction("Последний разбор", { sheet = ""; onInsight(insight.id) }) }
    }
    if (sheet == "plan") AppDialog("Упражнения", { sheet = "" }) {
        targets.forEachIndexed { index, target ->
            val exercise = state.exercises.find { it.id == target.exerciseId }
            ExerciseRow((index + 1).toString().padStart(2, '0'), exercise?.name ?: "Упражнение",
                "${target.sets} × ${target.minReps}–${target.maxReps}${if (exercise?.tracking == "reps_per_side") " на сторону" else ""}") {
                sheet = ""; onTechnique(target.exerciseId)
            }
        }
    }
}

@Composable fun ExerciseRow(number: String, name: String, detail: String, onClick: () -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth().clickable(role = Role.Button, onClick = onClick).heightIn(min = Space.Touch).padding(vertical = Space.Medium),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Space.Regular)) {
            Text(number, style = AppType.Label, color = AppColors.Secondary)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(Space.Tiny)) {
                Text(name, style = AppType.Body, color = AppColors.Text)
                Text(detail, style = AppType.Label, color = AppColors.Secondary)
            }
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, "Техника", tint = AppColors.Secondary, modifier = Modifier.size(Space.Icon))
        }
        DividerLine()
    }
}

@Preview(name = "Сегодня · 360", widthDp = 360, heightDp = 800, showBackground = true)
@Composable private fun TodayPreview() = WorkoutsTheme { TodayScreen(PreviewFixtures.state, {}, {}, {}, {}, {}, {}) }
